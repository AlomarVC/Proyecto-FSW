
package ejemplo6;

/*
 * @author Francisco Alomar Velázquez Curiel
 * informacion: 1628938 - IAS - 6to Semestre
 * INSTRUCCIONES: Arreglos
    Programa en java que guarda los valor pares en un arreglo de enteros. 
    Debe iterar del 1 al 100 y guardar solamente los números pares al arreglo.
    El arreglo debe tener el tamaño 50, ya que solamente guardara los números pares
    Cuando los guarde, imprimir el arreglo.
    Usar la estructura de contr😎l IF para separar los pares.
    Hacer uso de % (modulo) para poder saber si los numeros son pares o no
    La imagen anexada es del ejemplo en clase.
 */
public class Ejemplo6 {

    public static void main(String[] args) {
        
        //Declaramos e inicializamos un arreglo con tamaño de 50 espacios disponibles.
        int[] pares = new int [50];
        
        //Declaramos i para realizar el recorrido de los numeros del 1 al 100.
        //Declaramos cont (contador) el cual nos permitirá ir recorriendo el Arreglo
        //Espacio por espacio para llenar los 50 espacios disponibles para los num. pares
        int i, cont=0;
        
        for(i=1; i<= 100; i++){
            if(i%2==0){
                //Ej. primer numero par
                /*
                    ***Como en este punto i = 2 pasa por el if tomando estos valores:
                    pares[0] = 2; 
                    System.out.println(pares[0]); <--- Imprime el valor de i = 2 en el espacio [0].
                    cont += 1; <--- El contador ahora es 1.
                */
                
                pares[cont] = i; 
                System.out.println(pares[cont]);
                cont += 1;
            }else{
                //El else solo está puesto para hacer referencia a que los numeros impares
                //no tienen ninguna actividad en el programa.
            }
        }
    }    
}