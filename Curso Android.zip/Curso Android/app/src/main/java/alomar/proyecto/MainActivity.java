package alomar.proyecto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView Lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Lista = (RecyclerView) findViewById(R.id.Lista);

        ArrayList<String> comida = new ArrayList<>();

        comida.add("Hamburguesa");
        comida.add("Pollo Rostizado");
        comida.add("Albondigas");
        comida.add("Spaguetti");
        comida.add("Lasaña");
        comida.add("Mole Mexicano");
        comida.add("Caldo de Rez");
        comida.add("Tacos Alomar");
        comida.add("Pescado Empanizado");
        comida.add("Milanesa");

        MiAdaptador adaptador = new MiAdaptador(comida);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);

        Lista.setLayoutManager(layoutManager);
        Lista.setAdapter(adaptador);
    }
}
