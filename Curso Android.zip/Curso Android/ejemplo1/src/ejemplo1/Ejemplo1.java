
package ejemplo1;

/*
 * @author Francisco Alomar Velázquez Curiel
 * informacion: 1628938 - IAS - 6to Semestre
 * INSTRUCCIONES: Programa Java que lee un número entero por teclado, obtiene y muestra por pantalla el doble y el triple de ese número.
 */

import java.util.*; //Libreria para funciones avanzadas y basicas en JAVA//
public class Ejemplo1 {

    public static void main(String[] args) {
        
        //Introducimos un numero otorgado por el usuario mediante el teclado y lo mostramos en pantalla.//
        //Scanner se utiliza para obtener datos por medio de consola.//
        //System.out.println se utiliza para mostrar los datos en pantalla.//
        
        Scanner sc = new Scanner(System.in);
        int num;
        System.out.print("Introduce un numero entero: ");
        num = sc.nextInt();
        System.out.println("Numero introducido: " + num);
        
        //Doble del numero.//
        int doble = num*2;
        System.out.println("Doble de " + num + " es: " + doble);
        
        //Triple del numero.//
        int triple = num*3;
        System.out.println("Triple de " + num + " es: " + triple);
        
    }
    
}
