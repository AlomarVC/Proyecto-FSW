
package ejemplo4;
import java.util.*;

/*
 * @author Francisco Alomar Velázquez Curiel
 * informacion: 1628938 - IAS - 6to Semestre
 * INSTRUCCIONES: Programa Java que muestre los números del 1 al 100 utilizando la instrucción while
 */
public class Ejemplo4 {

    public static void main(String[] args) {
        int x=1;
        while(x<=100){
            System.out.println("Numero " + x );
            x++;
        }
    }
}
