
package ejemplo3;
import java.util.Scanner;
/*
 * @author Francisco Alomar Velázquez Curiel
 * informacion: 1628938 - IAS - 6to Semestre
 * INSTRUCCIONES: Programa Java que muestre los números del 1 al 100 utilizando la instrucción For
 */
public class Ejemplo3 {

    public static void main(String[] args) {
        int i;
        for(i=1; i<=100;i++){
            System.out.println("Numero " + i);
        }
    }
}
