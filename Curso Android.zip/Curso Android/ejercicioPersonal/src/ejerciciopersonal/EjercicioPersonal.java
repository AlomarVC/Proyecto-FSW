
package ejerciciopersonal;
import java.util.*;
public class EjercicioPersonal {

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Programa que imprime una cantidad X de numeros.");
        
        Scanner sc = new Scanner(System.in);
        int x,i;
        System.out.print("Introduzca un numero: ");
        x = sc.nextInt();
        System.out.println("Total de numeros a imprimir: " + x);
        for(i=1;i<=x;i++){
            System.out.println("Numero " + i + " impreso.");
        }
    }
    
}
