
package ejemplo5;

/*
 * @author Francisco Alomar Velázquez Curiel
 * informacion: 1628938 - IAS - 6to Semestre
 * INSTRUCCIONES: 
 */
public class Ejemplo5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i, cont=2;
        
        int[] pares = new int [6];
        int[] aleatorio;
        
        //Llenamos el array con números pares.
        //Utilizamos un contador.
        //Con el valor inicial 2 y le sumamos dos en cada
        //Iteracion.
        
        for(i=0; i< pares.length; i++){
            pares[i] = cont;
            cont += 2;
        }
        
        System.out.println("Pares: ");
        for(i=0; i < pares.length; i++){
            System.out.println(pares[i]);
        }
        
        //Lamamos a la funcion llenarArrayAleatorio
    }    
}
