
package miprimerholamundo;  //Nombre del Proyecto//

/*
 * @author Francisco Alomar Velázquez Curiel
 */
public class MiPrimerHolaMundo {    //Nombre de la Clase//

    public static void main(String[] args) {    //Aqui va TODO el codigo//
        System.out.println("Hola Mundo en Java");       //Muestra el mensaje en Comillas//
        
    }
    
}
