
package perros;

public class Perros {

    public static void main(String[] args) {
        System.out.println("Programa de Perros - JAVA");
        
        //Doggy
        Perro Doggy = new Perro("Azul", "Chihuahueño", "Miniatura", "Doggy");
        //Junior
        Perro Junior = new Perro("Blanco", "Chihuahueño", "Miniatura", "Junior");
        System.out.println(Junior.colorperro);
       
    }
    
}
