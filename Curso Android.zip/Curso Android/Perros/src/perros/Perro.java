
package perros;

public class Perro {
    //Atributos de los perros
    String colorperro;
    String razaperro;
    String tamañoperro;
    String nombreperro;
    
    public Perro(){
        colorperro = "Negro";
        razaperro = "General";
        tamañoperro = "Mediano";
        nombreperro = "Chilakil";
    }
    
    public Perro(String colorperro, String razaperro, String tamañoperro, String nombreperro){
        this.colorperro = colorperro;
        this.razaperro = razaperro;
        this.tamañoperro = tamañoperro;
        this.nombreperro = nombreperro;
    }
    
    public void setColorperro(String colorperro){
        this.colorperro = colorperro;
    }
    
    public void setRazaperro(String razaperro){
        this.razaperro = razaperro;
    }
    
    public void setTamañoperro(String tamañoperro){
        this.tamañoperro = tamañoperro;
    }
    
    public void setNombreperro(String nombreperro){
        this.nombreperro = nombreperro;
    }
    
    public String getColorperro(){
        return colorperro;
    }
    
    public String getRazaperro(){
        return razaperro;
    }
    
    public String getTamañoperro(){
        return tamañoperro;
    }
    
    public String getNombreperro(){
        return nombreperro;
    }
    
}
