
package miprimerhamburguesa;

/*
 * @author Alomar Velazquez - - - 1628938 - - - FIME
 */
public class Hamburguesa {
    //Atributos de la Hamburguesa
    String tipoDeQueso;
    String tipoDePan;
    boolean estaTostada;
    
    //Constructor vacio, en este se determinan valores por defecto para que no truene nuestro programa.
    public Hamburguesa(){
        tipoDePan = "Pan de avena";
    }
    
    //Constructor con valores iniciales
    public Hamburguesa(String tipoDeQueso, String tipoDePan, boolean estaTostada){
        this.tipoDeQueso = tipoDeQueso;
        this.tipoDePan = tipoDePan;
        this.estaTostada = estaTostada;
    }
    
    public void setTipoDeQueso(String tipoDeQueso){
        this.tipoDeQueso = tipoDeQueso;
    }
    
    public void setTipoDePan(String tipoDePan){
        this.tipoDePan = tipoDePan;
    }
    
    public void setEstaTostada(boolean estaTostada){
        this.estaTostada = estaTostada;
    }
    
    public String getTipoDeQueso(){
        return tipoDeQueso;
    }
    
    public String getTipoDePan(){
        return tipoDePan;
    }
    
    public boolean getEstaTostada(){
        return estaTostada;
    }
}
