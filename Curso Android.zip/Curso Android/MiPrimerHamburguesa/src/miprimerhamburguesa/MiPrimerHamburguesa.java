
package miprimerhamburguesa;

/*
 * @author Alomar Velazquez - - - 1628938 - - - FIME
 */
public class MiPrimerHamburguesa {

    public static void main(String[] args) {
        System.out.println("Hola mundo.");
        Hamburguesa burger = new Hamburguesa();
        System.out.println(burger.getTipoDePan());
        burger.setTipoDePan("Pan Blanco");
        System.out.println(burger.getTipoDePan());
        Hamburguesa burger2 = new Hamburguesa("Manchego", "Integral", true);
        System.out.println(burger2.getTipoDePan());
        System.out.println(burger2.getTipoDeQueso());
    }
    
}
