
package ejemplo2;

import java.util.Scanner;

/*
 * @author Francisco Alomar Velázquez Curiel
 * informacion: 1628938 - IAS - 6to Semestre
 * INSTRUCCIONES: Programa Java que lea un nombre y muestre por pantalla: “Buenos dias nombre_introducido”.
 */
public class Ejemplo2 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner (System.in);
        String nombre, apellido;
        //Introducimos el nombre por medio del teclado.
        System.out.print("Introduce tu nombre: ");
        
        //.nextLine vs .next
        //NextLine da posibilidad de obtener informacion a pesar de espacios otorgados por el usuario. Ej. Agregamos dos nombres en una misma linea.//
        nombre = sc.nextLine();
        System.out.print("Introduce tu apellido: ");
        //Next solamente nos permite poner informacion, si damos espacio lo siguiente que se escriba no lo lee.//
        apellido = sc.next();
        //Mensaje mostrado en Pantalla
        System.out.println("Buenos Días ¡" + nombre + " " + apellido + "!");
        
    }
    
}
